function on(buttonid) {
    var temp = document.getElementById(buttonid);
    temp.style.border = "1px solid #191970";
}

function out(buttonid) {
    var temp = document.getElementById(buttonid);
    temp.style.border = "none";
}

function addBook() {
    window.location.href = '增加书本.html';
}


function userquit() {
    window.location.href = '登录界面.html';
    localStorage.removeItem('userdata');
}

function getuserid() {
    var userdata = localStorage.getItem('userdata');
    if (userdata == null) {
        alert("请先登录！");
        window.location.href = '登录界面.html';
    }
    let temp = document.getElementById("titleuserid");
    if (userdata == "000000") {
        temp.textContent = "管理员：" + userdata;
    }
    else {
        temp.textContent = "用户：" + userdata;
    }
}