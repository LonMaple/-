function turnGrey() {
    var temp = document.getElementById("registerButton");
    temp.style.backgroundColor = "#696969";
}

function turnWhite() {
    var temp = document.getElementById("registerButton");
    temp.style.backgroundColor = "#FFFFFF";
}