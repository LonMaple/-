function on1(){
    var temp = document.getElementById("leftbutton")
    temp.style.border="1px solid #696969";
}
function on2(){
    var temp = document.getElementById("rightbutton")
    temp.style.border="1px solid #696969";
}
function out1(){
    var temp = document.getElementById("leftbutton")
    temp.style.border="none";
}
function out2(){
    var temp = document.getElementById("rightbutton")
    temp.style.border="none";
}
function checkregist(){
    window.location.href='注册界面.html';
}
