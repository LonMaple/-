function on(buttonid) {
    var temp = document.getElementById(buttonid);
    temp.style.border = "1px solid #191970";
}

function out(buttonid) {
    var temp = document.getElementById(buttonid);
    temp.style.border = "none";
}
