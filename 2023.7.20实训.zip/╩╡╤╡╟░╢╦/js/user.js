function getuserid(){
    var userdata = localStorage.getItem('userdata');
    if(userdata == null)
    {
        alert("请先登录！");
        window.location.href='登录界面.html';
    }
    let temp = document.getElementById("titleuserid");
    temp.textContent="用户："+userdata;
}

function on(buttonid){
    var temp = document.getElementById(buttonid);
    temp.style.border="1px solid #191970";
}

function out(buttonid){
    var temp = document.getElementById(buttonid);
    temp.style.border="none";
}

function userquit(){
    window.location.href='登录界面.html';
    localStorage.removeItem('userdata');
}

// 除了v-on:click以外另一个在点击借书按钮时触发的事件
function jieshu1(indexofbuttons){
    var temp = document.getElementById('index_'+indexofbuttons);
    temp.style.backgroundColor="#696969";
    temp.style.color="#FFFFFF";
}

//切换展示的表格
// function switchtable(tableid){
//     var tables = document.getElementsByClassName("booktable");
//     for(let i="0";i<tables.length;i++)
//     {
//         tables[i].style.display = "none";
//     }
//     var destable = document.getElementById(tableid);
//     destable.style.display = "flex";
// }
