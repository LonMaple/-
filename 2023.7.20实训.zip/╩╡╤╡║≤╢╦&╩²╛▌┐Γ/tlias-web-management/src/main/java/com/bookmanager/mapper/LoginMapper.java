package com.bookmanager.mapper;

import com.bookmanager.pojo.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;


@Mapper
public interface LoginMapper {
    @Select("select * from user where account = #{account} and password = #{password}")
    User getByAccountAndPassword(User user);

    @Insert("insert into user(account, password)" +
            "values(#{account}, #{password})")
    void insert(User user);
}
