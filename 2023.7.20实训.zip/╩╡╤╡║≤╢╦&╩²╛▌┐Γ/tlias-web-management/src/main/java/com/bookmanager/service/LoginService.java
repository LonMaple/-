package com.bookmanager.service;

import com.bookmanager.pojo.User;

public interface LoginService {
    User login(User user) ;

    void save(User user);
}
