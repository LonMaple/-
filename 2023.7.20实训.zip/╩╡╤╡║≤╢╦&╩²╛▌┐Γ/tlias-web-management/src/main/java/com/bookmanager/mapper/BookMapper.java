package com.bookmanager.mapper;

import com.bookmanager.pojo.Book;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDate;
import java.util.List;

/**
 * 员工管理
 */
@Mapper
public interface BookMapper {

    /**
     * 员工信息查询
     * @return
     *
     */
    public List<Book> list(String bookname,Integer lendNumber,LocalDate begin,LocalDate end);

    /**
     * 批量删除
     * @param ids
     */
    void delete(List<Integer> ids);

    @Insert("insert into book(bookname, ISBN, authorname, kind, releasedDate)" +
            "values(#{bookname}, #{ISBN}, #{authorname}, #{kind}, #{releasedDate})")
    void insert(Book book);

    @Select("select * from book where id = #{id}")
    Book getById(Integer id);

    void update(Book book);
}