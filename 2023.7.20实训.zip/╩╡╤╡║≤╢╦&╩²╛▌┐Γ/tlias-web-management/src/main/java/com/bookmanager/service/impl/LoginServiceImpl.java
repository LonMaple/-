package com.bookmanager.service.impl;

import com.bookmanager.mapper.LoginMapper;
import com.bookmanager.pojo.User;
import com.bookmanager.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl implements LoginService {

    @Autowired
    private LoginMapper loginMapper;

    @Override
    public User login(User user) {
        return loginMapper.getByAccountAndPassword(user);
    }

    @Override
    public void save(User user) { loginMapper.insert(user); }
}
