package com.bookmanager.controller;

import com.bookmanager.pojo.User;
import com.bookmanager.pojo.Result;
import com.bookmanager.service.LoginService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RestController
@CrossOrigin(origins = "*")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/login")
    public Result login(@RequestBody User user){
        log.info("用户登录: {}", user);
        User u = loginService.login(user);
        return  u != null?Result.success():Result.error("用户名或密码错误");
    }
    @PostMapping("/register")
    public Result save(@RequestBody User user){
        log.info("新增用户, user: {}", user);
        loginService.save(user);
        return Result.success();
    }

}
