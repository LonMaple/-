package com.bookmanager.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 员工实体类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    private Integer id; //ID
    private String bookname; //书名
    private String ISBN; //ISBN
    private String authorname; //作者姓名
    private Integer lendNumber; //Short to Integer
    private String image; //图像url
    private Short kind; //职位 , 1 班主任 , 2 讲师 , 3 学工主管 , 4 教研主管 , 5 咨询师
    private LocalDate releasedDate; //出版日期
    private LocalDateTime lendTime; //创建时间

}
