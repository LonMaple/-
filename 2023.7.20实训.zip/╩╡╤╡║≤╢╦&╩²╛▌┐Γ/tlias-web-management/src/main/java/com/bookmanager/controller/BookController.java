package com.bookmanager.controller;

import com.bookmanager.pojo.Book;
import com.bookmanager.pojo.PageBean;
import com.bookmanager.pojo.Result;
import com.bookmanager.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 图书管理Controller
 */
@Slf4j
@RestController
@CrossOrigin(origins = "*") // 允许来自http://example.com的跨域请求，缓存响应1小时
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public Result page(@RequestParam(defaultValue = "1") Integer page,
                       @RequestParam(defaultValue = "10") Integer pageSize,
                       String bookname, Integer lendNumber,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate begin,
                       @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate end)
    {
        log.info("分页查询, 参数: {},{},{},{},{},{}",page,pageSize,bookname, lendNumber,begin,end);
        //调用service分页查询
        PageBean pageBean = bookService.page(page,pageSize,bookname, lendNumber,begin,end);
        return Result.success(pageBean);
    }

    @DeleteMapping("/{ids}")
    public Result delete(@PathVariable List<Integer> ids){
        log.info("批量删除操作, ids:{}",ids);
        bookService.delete(ids);
        return Result.success();
    }

    @PostMapping
    public Result save(@RequestBody Book book){
        log.info("新增书本, book: {}", book);
        bookService.save(book);
        return Result.success();
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id){
        log.info("根据ID查询书本信息, id: {}",id);
        Book book = bookService.getById(id);
        return Result.success(book);
    }

    @PutMapping
    public Result update(@RequestBody Book book){
        log.info("更新书本信息 : {}", book);
        bookService.update(book);
        return Result.success();
    }

}
