package com.bookmanager.service;

import com.bookmanager.pojo.Book;
import com.bookmanager.pojo.PageBean;

import java.time.LocalDate;
import java.util.List;

/**
 * 员工管理
 */
public interface BookService {
    /**
     * 分页查询
     * @param page
     * @param pageSize
     * @return
     */
    PageBean page(Integer page, Integer pageSize,String name, Integer lendNumber,LocalDate begin,LocalDate end);

    /**
     * 批量删除
     * @param ids
     */
    void delete(List<Integer> ids);

    /**
     * 新增书本
     * @param book
     */
    void save(Book book);

    /**
     * 根据ID查询书本
     * @param id
     * @return
     */
    Book getById(Integer id);

    /**
     * 更新书本
     * @param book
     */
    void update(Book book);
}
