package com.bookmanager.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.bookmanager.mapper.BookMapper;
import com.bookmanager.pojo.Book;
import com.bookmanager.pojo.PageBean;
import com.bookmanager.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookMapper bookMapper;

    @Override
    public PageBean page(Integer page, Integer pageSize, String bookname, Integer lendNumber, LocalDate begin,LocalDate end) {
        //1. 设置分页参数
        PageHelper.startPage(page, pageSize);

        //2. 执行查询
        List<Book> bookList = bookMapper.list(bookname, lendNumber, begin, end);
        Page<Book> p = (Page<Book>) bookList;

        //3. 封装PageBean对象
        PageBean pageBean = new PageBean(p.getTotal(), p.getResult());
        return pageBean;
    }

    @Override
    public void delete(List<Integer> ids) {
        bookMapper.delete(ids);
    }

    @Override
    public void save(Book book){
        book.setLendNumber(0);
        book.setLendTime(LocalDateTime.now());
        book.setImage(" ");
        bookMapper.insert(book);
    }

    @Override
    public Book getById(Integer id) {
        return bookMapper.getById(id);
    }

    @Override
    public void update(Book book) {
        book.setLendTime(LocalDateTime.now());
        bookMapper.update(book);
    }
}